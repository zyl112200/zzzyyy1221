# 比奇堡（Bikini Bottom）— 海绵宝宝主题登录 + 钓鱼小游戏

比奇堡风格的全栈项目：海底背景、上升泡泡、游动小鱼、水母，纯 CSS 绘制的海绵宝宝（登录页）和派大星（注册页）。登录后进入 **钓鱼码头**，用「贝壳」货币购买钓竿 / 鱼饵 / 幸运物，抛竿钓鱼赚贝壳的循环玩法。

## 技术栈

| 端 | 技术 |
| --- | --- |
| 前端 | Vue 3 + Vite + Vue Router |
| 后端 | Spring Boot 3 + MyBatis-Plus + BCrypt |
| 数据库 | MySQL 8（生产） / **H2 内存库（本地免装，默认）** |

---

## 一键启动（推荐）

仓库内置启动脚本，**自动并行拉起前后端**（后端使用 H2 内存库，无需安装 MySQL），并会检测 / 兜底 Java、Maven、Node 环境：

| 系统 | 操作 |
| --- | --- |
| Windows | 双击 `start.bat`，或在项目根目录执行 `start.bat` |
| Linux / macOS | 先赋予执行权限：`chmod +x start.sh`，再运行 `./start.sh` |

脚本会自动检测 `node` / `java` / `mvn` 是否就绪（缺失会给出提示）。启动完成后：

- 后端：http://localhost:8080
- 前端：http://localhost:5173 （浏览器打开即可游玩）
- 默认账号：`spongebob` / `123456`

> 说明：Windows 脚本在 `PATH` 中找不到 Maven 时会兜底尝试 WorkBuddy 隔离目录下的 Maven；找不到 JDK 时会尝试常见 Zulu / Adoptium 安装路径。标准环境下（已安装并加入 `PATH`）无需任何改动。

## 快速开始（本地，无需安装 MySQL）

本仓库内置一个 **`h2` profile**，后端会自动用 H2 内存库启动，省去安装 MySQL 的步骤。

### 1) 启动后端（端口 8080）

```bash
cd backend
mvn -Dspring-boot.run.profiles=h2 -Dserver.port=8080 spring-boot:run
```

> 注意：若运行时出现 `Port 60827 was already in use`，是环境注入了 `SERVER__PORT` 覆盖端口，执行 `unset SERVER__PORT` 后重试即可。
> 生产环境用 MySQL：直接 `mvn spring-boot:run`（读默认 `application.yml`）。

### 2) 启动前端（端口 5173）

```bash
npm install
npm run dev
```

浏览器打开 http://localhost:5173 ，前端通过 Vite 代理把 `/api` 转发到 8080 后端。

### 3) 体验

- 用示例账号 **`spongebob` / `patrick`**（密码 `123456`）登录，或注册新号（新号自动获得 1 把初级钓竿 + 5 个鱼饵）。
- 进入 `/home` 钓鱼码头 → 抛竿消耗 1 个鱼饵、按钓力/幸运结算贝壳 → 去 `/shop` 买更好的竿/饵 → 在 `/inventory` 装备钓竿。

---

## 游戏玩法（贝壳经济）

- **贝壳 🐚**：游戏内货币。注册默认 50 个；钓鱼按鱼的品质获得贝壳（普通 15~35、稀有 120~220、传说 800~1500）。
- **鱼饵 🪱**：每次抛竿消耗 1 个，商店购买（普通饵 10🐚、豪华饵 25🐚 提升稀有概率）。
- **钓竿 🎣**：钓力越高，钓到稀有/传说鱼的概率越大。初级（钓力1、免费）、银质（2）、黄金（3）、钻石（4）。
- **幸运物 🍀**：拥有后稀有概率 +8%。

钓获概率：`稀有及以上 ≈ 10% + (钓力-1)×5% + 幸运?8% + 豪华饵?5%`（上限 55%），其中传说占该部分的 18%。

商店目录（`sql` / `data-h2.sql`）：

| id | 名称 | 类型 | 价格 | 钓力/说明 |
| -- | ---- | ---- | ---- | --------- |
| 1 | 初级钓竿 | ROD | 0 | 钓力 1（新号赠送） |
| 2 | 银质钓竿 | ROD | 200 | 钓力 2 |
| 3 | 黄金钓竿 | ROD | 800 | 钓力 3 |
| 4 | 钻石钓竿 | ROD | 3000 | 钓力 4 |
| 5 | 普通鱼饵 | BAIT | 10 | 每次消耗 1 |
| 6 | 豪华鱼饵 | BAIT | 35 | 钓力 +1，稀有概率提升 |
| 7 | 幸运四叶草 | LUCK | 500 | 稀有/传说概率 +8%（拥有即生效） |

---

## 页面路由

| 路径 | 页面 | 守卫 |
| --- | --- | --- |
| `/` | 登录页（海绵宝宝） | 已登录则跳 `/home` |
| `/register` | 注册页（派大星） | 已登录则跳 `/home` |
| `/home` | 钓鱼码头主页 | 需登录 |
| `/shop` | 渔具商店 | 需登录 |
| `/inventory` | 我的背包 | 需登录 |

## 后端接口

| 接口 | 说明 | 请求体 / 参数 |
| --- | --- | --- |
| `POST /api/auth/register` | 注册 | `{ "username", "email", "password" }` |
| `POST /api/auth/login` | 登录 | `{ "username", "password" }` |
| `GET  /api/game/me?username=` | 玩家档案（含背包、贝壳、装备） | query: username |
| `POST /api/game/fish` | 抛竿钓鱼（消耗饵、结算贝壳） | `{ "username" }` |
| `GET  /api/shop/items` | 商店目录 | — |
| `POST /api/shop/buy` | 购买道具 | `{ "username", "itemId", "quantity" }` |
| `POST /api/game/equip` | 装备钓竿 | `{ "username", "userItemId" }` |

统一返回：`{ "code": 200/400, "message": "...", "data": {...} }`，密码 BCrypt 加密存储。
> 说明：本项目为演示用途，未引入鉴权框架，接口通过 `username` 定位玩家（前后端本地会话存于 `sessionStorage`）。

---

## 初始化数据库（生产 / MySQL 模式）

```bash
mysql -uroot -p123456 < sql/spongebob_db.sql
```

脚本创建 `spongebob_db` 库、`user` / `item` / `user_item` 三张表，并写入示例账号与商店目录。

## 前端打包

```bash
npm run build     # 产物在 dist/
```

---

## 项目结构

```
├── index.html
├── package.json
├── vite.config.js            # Vite 配置（/api 代理到 8080）
├── sql/spongebob_db.sql      # MySQL 初始化脚本（含游戏三表 + 商店目录）
├── src/                      # 前端源码
│   ├── main.js
│   ├── App.vue
│   ├── api/{auth,game,http}.js
│   ├── store/session.js      # 登录态（sessionStorage）
│   ├── router/index.js       # 路由 + 登录守卫
│   ├── assets/main.css
│   ├── views/
│   │   ├── LoginView.vue       # 登录页
│   │   ├── RegisterView.vue    # 注册页
│   │   ├── HomeView.vue        # 钓鱼码头主页
│   │   ├── ShopView.vue        # 商店
│   │   └── InventoryView.vue   # 背包
│   └── components/
│       ├── OceanBackground.vue # 海底背景
│       ├── TopBar.vue          # 顶栏（贝壳余额 + 导航 + 退出）
│       ├── SpongeBob.vue / PatrickStar.vue
│       ├── LoginCard.vue / RegisterCard.vue
│       └── ToastMessage.vue
└── backend/                  # Spring Boot 后端
    ├── pom.xml               # 含 MySQL + H2 依赖
    └── src/main/
        ├── resources/
        │   ├── application.yml        # 默认 MySQL 数据源
        │   ├── application-h2.yml     # h2 profile：H2 内存库
        │   ├── schema-h2.sql / data-h2.sql
        └── java/com/bikinibottom/
            ├── controller/{Auth,Game,Shop}Controller.java
            ├── service/{User,Game}Service.java
            ├── mapper/{User,Item,UserItem}Mapper.java
            ├── entity/{User,Item,UserItem}.java
            ├── dto/                     # 请求 / 响应 DTO
            ├── config/                  # CORS、字段自动填充
            └── common/                  # 统一返回体、异常处理
```
