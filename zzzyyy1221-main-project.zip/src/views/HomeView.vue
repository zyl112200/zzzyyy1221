<script setup>
import { ref, reactive, onMounted } from 'vue'
import OceanBackground from '../components/OceanBackground.vue'
import TopBar from '../components/TopBar.vue'
import ToastMessage from '../components/ToastMessage.vue'
import { getSession } from '../store/session'
import { meApi, fishApi } from '../api/game'

const session = getSession()
const username = session ? session.username : ''

const profile = reactive({ username, shells: 0, equippedRodName: '无', equippedRodPower: 0, totalBait: 0, luckOwned: false, inventory: [] })
const fishing = ref(false)
const result = ref(null)
const recent = ref([])
const toastVisible = ref(false)
const toastMessage = ref('')
let timer = null

function showToast(msg) {
  toastMessage.value = msg
  toastVisible.value = true
  clearTimeout(timer)
  timer = setTimeout(() => { toastVisible.value = false }, 2600)
}

async function loadProfile() {
  try {
    const res = await meApi(username)
    if (res.code === 200) {
      Object.assign(profile, res.data)
    } else {
      showToast(res.message || '加载失败')
    }
  } catch (e) {
    showToast(e.message || '后端未启动，先 npm run dev + 启动后端 🌊')
  }
}

async function cast() {
  if (fishing.value) return
  if (profile.totalBait <= 0) {
    showToast('鱼饵用完啦，去商店买点 🪱')
    return
  }
  fishing.value = true
  try {
    const res = await fishApi(username)
    if (res.code === 200) {
      result.value = res.data
      profile.shells = res.data.shells
      profile.totalBait = res.data.totalBait
      recent.value.unshift({
        icon: res.data.fishIcon,
        name: res.data.fishName,
        reward: res.data.reward,
        tier: res.data.tier
      })
      if (recent.value.length > 8) recent.value.pop()
    } else {
      showToast(res.message || '抛竿失败')
    }
  } catch (e) {
    showToast(e.message || '后端开小差了 🌊')
  } finally {
    fishing.value = false
  }
}

function closeResult() {
  result.value = null
}

function tierLabel(t) {
  return t === 'LEGENDARY' ? '传说' : t === 'RARE' ? '稀有' : '普通'
}

onMounted(loadProfile)
</script>

<template>
  <div class="page">
    <TopBar :shells="profile.shells" />
    <OceanBackground />

    <main class="dock">
      <h2 class="title">🎣 比奇堡钓鱼码头</h2>
      <p class="sub">抛竿、钓鱼、攒贝壳，去商店升级你的装备！</p>

      <div class="stats">
        <div class="stat shell">
          <span class="big">🐚 {{ profile.shells }}</span>
          <span class="label">贝壳余额</span>
        </div>
        <div class="stat">
          <span class="big">🎣 {{ profile.equippedRodName }}</span>
          <span class="label">当前钓竿（钓力 {{ profile.equippedRodPower }}）</span>
        </div>
        <div class="stat">
          <span class="big">🪱 {{ profile.totalBait }}</span>
          <span class="label">鱼饵数量</span>
        </div>
      </div>

      <div class="rod-area">
        <div class="rod" :class="{ casting: fishing }">🎣</div>
        <div class="bobber" :class="{ drop: fishing }">🟠</div>
        <div class="ripple" :class="{ active: fishing }"></div>
      </div>

      <button class="cast-btn" @click="cast" :disabled="fishing || profile.totalBait <= 0">
        {{ fishing ? '抛竿中…' : (profile.totalBait > 0 ? '抛竿钓鱼 🎣' : '鱼饵不足，去商店 🪱') }}
      </button>
      <p class="hint">每次抛竿消耗 1 个鱼饵，钓到的鱼会换成贝壳 🐚</p>

      <div class="recent" v-if="recent.length">
        <h3>📜 最近钓获</h3>
        <ul>
          <li v-for="(r, i) in recent" :key="i" :class="'tier-' + r.tier.toLowerCase()">
            <span class="ico">{{ r.icon }}</span>
            <span class="nm">{{ r.name }}</span>
            <span class="rw">+{{ r.reward }} 🐚</span>
          </li>
        </ul>
      </div>
    </main>

    <!-- 钓获弹窗 -->
    <div class="overlay" v-if="result" @click="closeResult">
      <div class="catch-card" :class="'tier-' + result.tier.toLowerCase()" @click.stop>
        <div class="tier-badge">{{ tierLabel(result.tier) }}</div>
        <div class="fish-pop">{{ result.fishIcon }}</div>
        <h3>{{ result.fishName }}</h3>
        <p class="reward">+{{ result.reward }} 🐚</p>
        <p class="msg">{{ result.message }}</p>
        <button class="ok" @click="closeResult">收竿 🎣</button>
      </div>
    </div>

    <ToastMessage :message="toastMessage" :visible="toastVisible" />
  </div>
</template>

<style scoped>
.page {
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}
.dock {
  position: relative;
  z-index: 10;
  max-width: 640px;
  margin: 28px auto 60px;
  padding: 26px 24px 30px;
  background: rgba(255, 255, 255, 0.92);
  border-radius: 26px;
  box-shadow: 0 24px 60px rgba(1, 40, 80, .4), inset 0 0 0 4px #ffd54f;
  text-align: center;
}
.title {
  color: #f9a825;
  font-size: 26px;
  letter-spacing: 2px;
  text-shadow: 2px 2px 0 #0277bd, 4px 4px 0 rgba(2, 119, 189, .2);
  margin-bottom: 2px;
}
.sub { color: #0288d1; font-size: 13px; margin-bottom: 18px; }

.stats {
  display: flex;
  gap: 12px;
  justify-content: center;
  flex-wrap: wrap;
  margin-bottom: 18px;
}
.stat {
  flex: 1 1 150px;
  background: #fffde7;
  border: 3px solid #ffe082;
  border-radius: 16px;
  padding: 12px 8px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.stat.shell { background: #fff3e0; border-color: #ffb74d; }
.stat .big { font-size: 20px; font-weight: bold; color: #4e342e; }
.stat .label { font-size: 12px; color: #0277bd; }

.rod-area {
  position: relative;
  height: 120px;
  margin: 8px 0 6px;
}
.rod {
  position: absolute;
  left: 50%;
  top: 0;
  transform: translateX(-50%) rotate(0deg);
  font-size: 64px;
  transform-origin: 50% 90%;
  transition: transform .3s;
}
.rod.casting { animation: cast .9s ease-in-out infinite; }
@keyframes cast {
  0%,100% { transform: translateX(-50%) rotate(0deg); }
  50% { transform: translateX(-50%) rotate(-28deg); }
}
.bobber {
  position: absolute;
  left: 50%;
  top: 70px;
  transform: translateX(-50%);
  font-size: 26px;
  opacity: 0;
}
.bobber.drop { animation: bob 1s ease-in infinite; opacity: 1; }
@keyframes bob {
  0% { top: 60px; opacity: 0; }
  30% { opacity: 1; }
  100% { top: 100px; opacity: .7; }
}
.ripple {
  position: absolute;
  left: 50%;
  top: 104px;
  width: 20px;
  height: 20px;
  border: 3px solid rgba(255,255,255,.8);
  border-radius: 50%;
  transform: translateX(-50%);
  opacity: 0;
}
.ripple.active { animation: ripple 1s ease-out infinite; }
@keyframes ripple {
  0% { width: 10px; height: 10px; opacity: .9; }
  100% { width: 120px; height: 120px; opacity: 0; }
}

.cast-btn {
  margin-top: 8px;
  padding: 15px 36px;
  border: none;
  border-radius: 18px;
  font-size: 18px;
  font-weight: bold;
  letter-spacing: 3px;
  color: #4e2600;
  cursor: pointer;
  background: linear-gradient(180deg, #ffe14d, #ffb300);
  box-shadow: 0 6px 0 #c17900, 0 10px 18px rgba(1, 40, 80, .3);
  transition: transform .12s, box-shadow .12s;
}
.cast-btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 8px 0 #c17900; }
.cast-btn:active:not(:disabled) { transform: translateY(3px); box-shadow: 0 2px 0 #c17900; }
.cast-btn:disabled { opacity: .6; cursor: not-allowed; }
.hint { color: #0277bd; font-size: 13px; margin-top: 12px; }

.recent { margin-top: 22px; text-align: left; }
.recent h3 { color: #f9a825; font-size: 16px; margin-bottom: 8px; }
.recent ul { list-style: none; display: flex; flex-direction: column; gap: 6px; }
.recent li {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  border-radius: 12px;
  background: #e3f2fd;
  font-weight: bold;
  color: #37474f;
}
.recent li .ico { font-size: 20px; }
.recent li .nm { flex: 1; }
.recent li .rw { color: #ef6c00; }
.recent li.tier-rare { background: #ede7f6; }
.recent li.tier-rare .rw { color: #7e57c2; }
.recent li.tier-legendary { background: #fff8e1; box-shadow: inset 0 0 0 2px #ffb300; }
.recent li.tier-legendary .rw { color: #f9a825; }

.overlay {
  position: fixed;
  inset: 0;
  background: rgba(1, 40, 80, .55);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 50;
}
.catch-card {
  background: #fff;
  border-radius: 24px;
  padding: 28px 36px;
  text-align: center;
  box-shadow: 0 20px 50px rgba(0,0,0,.4);
  position: relative;
  animation: pop .35s cubic-bezier(.68,-0.55,.27,1.55);
}
@keyframes pop { from { transform: scale(.6); opacity: 0; } to { transform: scale(1); opacity: 1; } }
.catch-card.tier-rare { box-shadow: 0 0 0 4px #7e57c2, 0 20px 50px rgba(0,0,0,.4); }
.catch-card.tier-legendary { box-shadow: 0 0 0 5px #ffb300, 0 20px 50px rgba(0,0,0,.4); }
.tier-badge {
  position: absolute;
  top: -14px;
  left: 50%;
  transform: translateX(-50%);
  background: #90a4ae;
  color: #fff;
  padding: 4px 16px;
  border-radius: 12px;
  font-weight: bold;
  font-size: 13px;
}
.catch-card.tier-rare .tier-badge { background: #7e57c2; }
.catch-card.tier-legendary .tier-badge { background: #f9a825; }
.fish-pop {
  font-size: 84px;
  animation: float 1.6s ease-in-out infinite;
  margin: 10px 0;
}
@keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-12px); } }
.catch-card h3 { color: #37474f; font-size: 22px; margin-bottom: 4px; }
.reward { color: #ef6c00; font-size: 22px; font-weight: bold; margin: 6px 0; }
.catch-card.tier-rare .reward { color: #7e57c2; }
.catch-card.tier-legendary .reward { color: #f9a825; }
.msg { color: #607d8b; font-size: 13px; margin-bottom: 16px; }
.ok {
  padding: 10px 28px;
  border: none;
  border-radius: 14px;
  font-weight: bold;
  font-size: 15px;
  color: #4e2600;
  cursor: pointer;
  background: linear-gradient(180deg, #ffe14d, #ffb300);
}
</style>
