<script setup>
import { ref, computed, onMounted } from 'vue'
import OceanBackground from '../components/OceanBackground.vue'
import TopBar from '../components/TopBar.vue'
import ToastMessage from '../components/ToastMessage.vue'
import { getSession } from '../store/session'
import { meApi, equipApi } from '../api/game'

const session = getSession()
const username = session ? session.username : ''

const profile = ref({ username, shells: 0, equippedRodName: '无', totalBait: 0, inventory: [] })
const equipping = ref(null)
const toastVisible = ref(false)
const toastMessage = ref('')
let timer = null

function showToast(msg) {
  toastMessage.value = msg
  toastVisible.value = true
  clearTimeout(timer)
  timer = setTimeout(() => { toastVisible.value = false }, 2600)
}

const rods = computed(() => profile.value.inventory.filter((i) => i.type === 'ROD'))
const baits = computed(() => profile.value.inventory.filter((i) => i.type === 'BAIT'))
const luck = computed(() => profile.value.inventory.filter((i) => i.type === 'LUCK'))

async function load() {
  try {
    const res = await meApi(username)
    if (res.code === 200) profile.value = res.data
    else showToast(res.message || '加载失败')
  } catch (e) { showToast(e.message || '后端未启动 🌊') }
}

async function equip(rod) {
  if (rod.equipped) return
  equipping.value = rod.userItemId
  try {
    const res = await equipApi(username, rod.userItemId)
    if (res.code === 200) {
      profile.value = res.data
      showToast('已装备 ' + rod.name + ' 🎣')
    } else showToast(res.message || '装备失败')
  } catch (e) { showToast(e.message || '后端开小差了 🌊') }
  finally { equipping.value = null }
}

onMounted(load)
</script>

<template>
  <div class="page">
    <TopBar :shells="profile.shells" />
    <OceanBackground />

    <main class="inv">
      <h2 class="title">🎒 我的背包</h2>
      <p class="sub">管理你的钓竿与道具，装备更强的竿能钓到更值钱的鱼！</p>

      <section>
        <h3>🎣 钓竿</h3>
        <div class="row" v-if="rods.length">
          <div class="item" v-for="rod in rods" :key="rod.userItemId" :class="{ on: rod.equipped }">
            <div class="ico">{{ rod.icon }}</div>
            <div class="meta">
              <div class="nm">{{ rod.name }} <span class="lvl">钓力 {{ rod.power }}</span></div>
              <div class="q">×{{ rod.quantity }}</div>
            </div>
            <button class="equip" :class="{ active: rod.equipped }" @click="equip(rod)" :disabled="rod.equipped || equipping === rod.userItemId">
              {{ rod.equipped ? '已装备' : (equipping === rod.userItemId ? '装备中…' : '装备') }}
            </button>
          </div>
        </div>
        <p class="empty" v-else>还没有钓竿，去商店看看吧 🛒</p>
      </section>

      <section>
        <h3>🪱 鱼饵（共 {{ profile.totalBait }} 个）</h3>
        <div class="row" v-if="baits.length">
          <div class="item" v-for="b in baits" :key="b.userItemId">
            <div class="ico">{{ b.icon }}</div>
            <div class="meta">
              <div class="nm">{{ b.name }}</div>
              <div class="q">×{{ b.quantity }}</div>
            </div>
            <span class="tag">{{ b.power > 0 ? '豪华' : '普通' }}</span>
          </div>
        </div>
        <p class="empty" v-else>没有鱼饵了，抛竿需要鱼饵哦 🪱</p>
      </section>

      <section v-if="luck.length">
        <h3>🍀 幸运物</h3>
        <div class="row">
          <div class="item" v-for="l in luck" :key="l.userItemId">
            <div class="ico">{{ l.icon }}</div>
            <div class="meta">
              <div class="nm">{{ l.name }}</div>
              <div class="q">×{{ l.quantity }}（已生效）</div>
            </div>
          </div>
        </div>
      </section>
    </main>

    <ToastMessage :message="toastMessage" :visible="toastVisible" />
  </div>
</template>

<style scoped>
.page { min-height: 100vh; position: relative; overflow: hidden; }
.inv {
  position: relative;
  z-index: 10;
  max-width: 720px;
  margin: 28px auto 60px;
  padding: 26px 24px 30px;
  background: rgba(255, 255, 255, 0.93);
  border-radius: 24px;
  box-shadow: 0 20px 50px rgba(1, 40, 80, .38), inset 0 0 0 4px #ffd54f;
}
.title {
  color: #f9a825;
  font-size: 26px;
  letter-spacing: 2px;
  text-shadow: 2px 2px 0 #0277bd, 4px 4px 0 rgba(2, 119, 189, .2);
  text-align: center;
}
.sub { color: #0288d1; font-size: 13px; text-align: center; margin-bottom: 18px; }
section { margin-bottom: 22px; }
section h3 { color: #0277bd; font-size: 17px; margin-bottom: 10px; }
.row { display: flex; flex-direction: column; gap: 10px; }
.item {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 12px 14px;
  border-radius: 16px;
  background: #e3f2fd;
}
.item.on { background: #fff8e1; box-shadow: inset 0 0 0 2px #ffb300; }
.ico { font-size: 38px; }
.meta { flex: 1; }
.nm { font-weight: bold; color: #37474f; font-size: 16px; }
.lvl { font-size: 12px; color: #7e57c2; margin-left: 6px; font-weight: bold; }
.q { font-size: 13px; color: #607d8b; }
.tag { background: #7e57c2; color: #fff; padding: 3px 10px; border-radius: 10px; font-size: 12px; font-weight: bold; }
.equip {
  border: none;
  border-radius: 12px;
  padding: 9px 16px;
  font-weight: bold;
  cursor: pointer;
  color: #4e2600;
  background: linear-gradient(180deg, #ffe14d, #ffb300);
  box-shadow: 0 4px 0 #c17900;
}
.equip.active { background: #cfd8dc; color: #607d8b; box-shadow: none; cursor: default; }
.equip:disabled:not(.active) { opacity: .6; }
.empty { color: #90a4ae; font-size: 14px; }
</style>
