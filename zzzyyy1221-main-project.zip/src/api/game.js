/**
 * 钓鱼小游戏 / 商店接口封装
 */
import { request, get } from './http'

/** 玩家档案：GET /api/game/me?username= */
export const meApi = (username) =>
  get('/api/game/me?username=' + encodeURIComponent(username))

/** 商品目录：GET /api/shop/items */
export const shopItemsApi = () => get('/api/shop/items')

/** 购买：POST /api/shop/buy */
export const buyApi = (username, itemId, quantity = 1) =>
  request('/api/shop/buy', { username, itemId, quantity })

/** 抛竿钓鱼：POST /api/game/fish */
export const fishApi = (username) => request('/api/game/fish', { username })

/** 装备钓竿：POST /api/game/equip */
export const equipApi = (username, userItemId) =>
  request('/api/game/equip', { username, userItemId })
