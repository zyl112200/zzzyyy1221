<script setup>
import { useRouter } from 'vue-router'
import { clearSession, getSession } from '../store/session'

const props = defineProps({
  shells: { type: Number, default: 0 }
})

const router = useRouter()
const session = getSession()
const username = session ? session.username : ''

function logout() {
  clearSession()
  router.push('/')
}
</script>

<template>
  <header class="topbar">
    <div class="brand">🏝️ 比奇堡钓鱼</div>
    <nav class="nav">
      <router-link to="/home">🎣 码头</router-link>
      <router-link to="/shop">🛒 商店</router-link>
      <router-link to="/inventory">🎒 背包</router-link>
    </nav>
    <div class="right">
      <span class="shell">🐚 {{ shells }}</span>
      <span class="user">{{ username }}</span>
      <button class="logout" @click="logout">退出</button>
    </div>
  </header>
</template>

<style scoped>
.topbar {
  position: sticky;
  top: 0;
  z-index: 30;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 10px 20px;
  background: rgba(2, 60, 110, 0.82);
  backdrop-filter: blur(8px);
  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.25);
  flex-wrap: wrap;
}
.brand {
  font-weight: bold;
  font-size: 18px;
  letter-spacing: 1px;
  color: #fff;
  text-shadow: 1px 1px 0 #01477f;
}
.nav {
  display: flex;
  gap: 8px;
}
.nav a {
  color: #cdeffd;
  text-decoration: none;
  padding: 6px 12px;
  border-radius: 10px;
  font-weight: bold;
  transition: background .2s, color .2s;
}
.nav a:hover { background: rgba(255, 255, 255, 0.12); }
.nav a.router-link-active {
  background: rgba(255, 255, 255, 0.22);
  color: #fff;
}
.right {
  display: flex;
  align-items: center;
  gap: 12px;
}
.shell {
  background: rgba(255, 255, 255, 0.18);
  padding: 6px 14px;
  border-radius: 16px;
  font-weight: bold;
  font-size: 16px;
  color: #fff;
}
.user { color: #e3f4ff; opacity: .9; }
.logout {
  background: #ff6b6b;
  border: none;
  color: #fff;
  padding: 6px 14px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: bold;
}
.logout:hover { background: #ff5252; }
</style>
