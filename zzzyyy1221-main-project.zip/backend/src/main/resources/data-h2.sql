-- ============================================================
-- 示例数据（H2 内存库）
-- 密码均为 BCrypt 加密后的 123456；shells 走字段默认值 50
-- ============================================================

INSERT INTO user (username, email, password) VALUES
  ('spongebob', 'spongebob@bikini.bottom', '$2a$10$6abzJLWM0DkWMUz/U0jTLeJgDVZvWlyNv9zeGx0vqMEh6RhEaIndC'),
  ('patrick',   'patrick@bikini.bottom',   '$2a$10$dKiaOy1ff6HO3SvKQnAlUOVK8nmrcLhYAxdzVM02MYvDL6wXAjoTy');

-- 商店商品目录（id 固定，便于逻辑引用）
INSERT INTO item (id, name, type, price, power, icon, description, sort) VALUES
  (1, '初级钓竿',   'ROD',  0,    1, '🎣', '比奇堡标配，能钓到常见小鱼',    10),
  (2, '银质钓竿',   'ROD',  200,  2, '🎣', '钓力提升，稀有鱼更易上钩',      20),
  (3, '黄金钓竿',   'ROD',  800,  3, '🎣', '闪闪发光，传说鱼也拦不住',      30),
  (4, '钻石钓竿',   'ROD',  3000, 4, '🎣', '深海霸主专用，极品钓力',        40),
  (5, '普通鱼饵',   'BAIT', 10,   0, '🪱', '每次抛竿消耗 1 个',            50),
  (6, '豪华鱼饵',   'BAIT', 35,   1, '🦐', '提升稀有鱼概率',              60),
  (7, '幸运四叶草', 'LUCK', 500,  2, '🍀', '永久提升稀有 / 传说概率',      70);

-- 示例账号初始道具：1 把初级钓竿（已装备）+ 5 个普通鱼饵
INSERT INTO user_item (user_id, item_id, quantity, equipped) VALUES
  (1, 1, 1, 1), (1, 5, 5, 0),
  (2, 1, 1, 1), (2, 5, 5, 0);
