package com.bikinibottom.dto;

import lombok.Data;

import java.util.List;

/**
 * 玩家游戏档案（前端主页 / 背包展示用）
 */
@Data
public class GameProfile {

    /** 用户名 */
    private String username;

    /** 贝壳余额 */
    private Integer shells;

    /** 已装备钓竿名称 */
    private String equippedRodName;

    /** 已装备钓竿钓力 */
    private Integer equippedRodPower;

    /** 鱼饵总数 */
    private Integer totalBait;

    /** 是否拥有幸运物 */
    private Boolean luckOwned;

    /** 背包明细 */
    private List<OwnedItemDto> inventory;
}
