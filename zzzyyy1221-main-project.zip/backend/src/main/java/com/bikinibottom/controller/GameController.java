package com.bikinibottom.controller;

import com.bikinibottom.common.Result;
import com.bikinibottom.dto.EquipRequest;
import com.bikinibottom.dto.FishResult;
import com.bikinibottom.dto.GameProfile;
import com.bikinibottom.service.GameService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 钓鱼小游戏接口
 */
@RestController
@RequestMapping("/api/game")
public class GameController {

    private final GameService gameService;

    public GameController(GameService gameService) {
        this.gameService = gameService;
    }

    /** 获取玩家档案：GET /api/game/me?username=xxx */
    @GetMapping("/me")
    public Result<GameProfile> me(@RequestParam String username) {
        return gameService.me(username);
    }

    /** 抛竿钓鱼：POST /api/game/fish  { "username": "xxx" } */
    @PostMapping("/fish")
    public Result<FishResult> fish(@RequestBody Map<String, String> body) {
        return gameService.fish(body.get("username"));
    }

    /** 装备钓竿：POST /api/game/equip { "username": "xxx", "userItemId": 1 } */
    @PostMapping("/equip")
    public Result<GameProfile> equip(@RequestBody EquipRequest req) {
        return gameService.equip(req.getUsername(), req.getUserItemId());
    }
}
