package com.bikinibottom.service;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.bikinibottom.common.Result;
import com.bikinibottom.dto.FishResult;
import com.bikinibottom.dto.GameProfile;
import com.bikinibottom.dto.OwnedItemDto;
import com.bikinibottom.entity.Item;
import com.bikinibottom.entity.User;
import com.bikinibottom.entity.UserItem;
import com.bikinibottom.mapper.ItemMapper;
import com.bikinibottom.mapper.UserItemMapper;
import com.bikinibottom.mapper.UserMapper;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * 比奇堡钓鱼小游戏业务：贝壳经济 + 商店 + 抛竿
 * <p>说明：本项目未引入鉴权框架，接口通过 username 定位玩家（演示用途）。</p>
 */
@Service
public class GameService {

    private final UserMapper userMapper;
    private final ItemMapper itemMapper;
    private final UserItemMapper userItemMapper;
    private final Random random = new Random();

    public GameService(UserMapper userMapper, ItemMapper itemMapper, UserItemMapper userItemMapper) {
        this.userMapper = userMapper;
        this.itemMapper = itemMapper;
        this.userItemMapper = userItemMapper;
    }

    private User getUser(String username) {
        return userMapper.selectOne(Wrappers.<User>lambdaQuery().eq(User::getUsername, username));
    }

    /** 玩家档案（含确保初始道具） */
    public Result<GameProfile> me(String username) {
        User u = getUser(username);
        if (u == null) {
            return Result.error("比奇堡查无此人 🐙");
        }
        ensureStarterPack(u.getId());
        return Result.success(buildProfile(u));
    }

    /** 新玩家兜底：1 把初级钓竿（已装备）+ 5 个普通鱼饵 */
    private void ensureStarterPack(Long userId) {
        Long rodCount = userItemMapper.selectCount(
                Wrappers.<UserItem>lambdaQuery().eq(UserItem::getUserId, userId).eq(UserItem::getItemId, 1L));
        if (rodCount != null && rodCount == 0) {
            UserItem rod = new UserItem();
            rod.setUserId(userId);
            rod.setItemId(1L);
            rod.setQuantity(1);
            rod.setEquipped(1);
            userItemMapper.insert(rod);

            UserItem bait = new UserItem();
            bait.setUserId(userId);
            bait.setItemId(5L);
            bait.setQuantity(5);
            bait.setEquipped(0);
            userItemMapper.insert(bait);
        }
    }

    private GameProfile buildProfile(User u) {
        GameProfile p = new GameProfile();
        p.setUsername(u.getUsername());
        p.setShells(u.getShells());

        Map<Long, Item> itemMap = itemMapper.selectList(null).stream()
                .collect(Collectors.toMap(Item::getId, i -> i));

        List<UserItem> owned = userItemMapper.selectList(
                Wrappers.<UserItem>lambdaQuery().eq(UserItem::getUserId, u.getId()));

        int totalBait = 0;
        boolean luckOwned = false;
        Item equippedRod = null;

        List<OwnedItemDto> inventory = new ArrayList<>();
        for (UserItem ui : owned) {
            Item it = itemMap.get(ui.getItemId());
            if (it == null) {
                continue;
            }
            if ("BAIT".equals(it.getType())) {
                totalBait += ui.getQuantity();
            }
            if ("LUCK".equals(it.getType()) && ui.getQuantity() > 0) {
                luckOwned = true;
            }
            if ("ROD".equals(it.getType()) && ui.getEquipped() != null && ui.getEquipped() == 1) {
                equippedRod = it;
            }
            OwnedItemDto dto = new OwnedItemDto();
            dto.setUserItemId(ui.getId());
            dto.setItemId(it.getId());
            dto.setName(it.getName());
            dto.setType(it.getType());
            dto.setIcon(it.getIcon());
            dto.setPrice(it.getPrice());
            dto.setPower(it.getPower());
            dto.setDescription(it.getDescription());
            dto.setQuantity(ui.getQuantity());
            dto.setEquipped(ui.getEquipped());
            inventory.add(dto);
        }

        // 没有显式装备的竿时，自动选用钓力最高的竿
        if (equippedRod == null) {
            equippedRod = inventory.stream()
                    .filter(d -> "ROD".equals(d.getType()))
                    .max(Comparator.comparingInt(OwnedItemDto::getPower))
                    .map(d -> itemMap.get(d.getItemId()))
                    .orElse(null);
        }

        p.setEquippedRodName(equippedRod != null ? equippedRod.getName() : "无");
        p.setEquippedRodPower(equippedRod != null ? equippedRod.getPower() : 0);
        p.setTotalBait(totalBait);
        p.setLuckOwned(luckOwned);
        p.setInventory(inventory);
        return p;
    }

    /** 商店目录 */
    public Result<List<Item>> shopItems() {
        List<Item> items = itemMapper.selectList(
                Wrappers.<Item>lambdaQuery().orderByAsc(Item::getSort));
        return Result.success(items);
    }

    /** 购买：扣贝壳 + 入库（首把竿自动装备） */
    public Result<GameProfile> buy(String username, Long itemId, Integer quantity) {
        if (quantity == null || quantity < 1) {
            quantity = 1;
        }
        User u = getUser(username);
        if (u == null) {
            return Result.error("比奇堡查无此人 🐙");
        }
        Item item = itemMapper.selectById(itemId);
        if (item == null) {
            return Result.error("商店里没有这件商品");
        }
        int cost = item.getPrice() * quantity;
        if (u.getShells() < cost) {
            return Result.error("贝壳不够啦，先去钓鱼赚点 🐚");
        }

        u.setShells(u.getShells() - cost);
        userMapper.updateById(u);

        boolean hasEquippedRod = userItemMapper.selectCount(
                Wrappers.<UserItem>lambdaQuery().eq(UserItem::getUserId, u.getId()).eq(UserItem::getEquipped, 1)) > 0;

        UserItem existing = userItemMapper.selectOne(
                Wrappers.<UserItem>lambdaQuery().eq(UserItem::getUserId, u.getId()).eq(UserItem::getItemId, itemId));
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + quantity);
            userItemMapper.updateById(existing);
        } else {
            UserItem ui = new UserItem();
            ui.setUserId(u.getId());
            ui.setItemId(itemId);
            ui.setQuantity(quantity);
            ui.setEquipped(("ROD".equals(item.getType()) && !hasEquippedRod) ? 1 : 0);
            userItemMapper.insert(ui);
        }
        return Result.success("购买成功 🎉", buildProfile(u));
    }

    /** 装备钓竿 */
    public Result<GameProfile> equip(String username, Long userItemId) {
        User u = getUser(username);
        if (u == null) {
            return Result.error("比奇堡查无此人 🐙");
        }
        UserItem target = userItemMapper.selectById(userItemId);
        if (target == null || !target.getUserId().equals(u.getId())) {
            return Result.error("背包里没有这件道具");
        }
        Item it = itemMapper.selectById(target.getItemId());
        if (it == null || !"ROD".equals(it.getType())) {
            return Result.error("只有钓竿才能装备");
        }
        // 取消全部竿的装备，再装备这一把
        userItemMapper.update(null, Wrappers.<UserItem>lambdaUpdate()
                .eq(UserItem::getUserId, u.getId())
                .set(UserItem::getEquipped, 0));
        target.setEquipped(1);
        userItemMapper.updateById(target);
        return Result.success("已装备 " + it.getName(), buildProfile(u));
    }

    /** 抛竿钓鱼：消耗 1 鱼饵，按钓力/幸运概率出鱼，结算贝壳 */
    public Result<FishResult> fish(String username) {
        User u = getUser(username);
        if (u == null) {
            return Result.error("比奇堡查无此人 🐙");
        }
        ensureStarterPack(u.getId());

        GameProfile profile = buildProfile(u);
        if (profile.getEquippedRodPower() == 0) {
            return Result.error("你还没有钓竿，先去商店看看 🎣");
        }
        if (profile.getTotalBait() <= 0) {
            return Result.error("没有鱼饵了，去商店买点 🪱");
        }

        boolean premiumBait = consumeBait(u.getId());
        int rodPower = profile.getEquippedRodPower();
        boolean luck = Boolean.TRUE.equals(profile.getLuckOwned());

        // 稀有/传说概率随钓力、豪华饵、幸运物提升
        double rareOrBetter = 0.10 + (rodPower - 1) * 0.05 + (luck ? 0.08 : 0) + (premiumBait ? 0.05 : 0);
        if (rareOrBetter > 0.55) {
            rareOrBetter = 0.55;
        }
        double legendary = rareOrBetter * 0.18;

        double roll = random.nextDouble();
        String tier;
        if (roll < legendary) {
            tier = "LEGENDARY";
        } else if (roll < rareOrBetter) {
            tier = "RARE";
        } else {
            tier = "COMMON";
        }

        Fish fish = pickFish(tier);
        int reward = fish.value;

        u.setShells(u.getShells() + reward);
        userMapper.updateById(u);

        FishResult r = new FishResult();
        r.setFishName(fish.name);
        r.setFishIcon(fish.icon);
        r.setTier(tier);
        r.setReward(reward);
        r.setShells(u.getShells());
        r.setTotalBait(profile.getTotalBait() - 1);
        r.setMessage(tierMessage(tier, fish));
        return Result.success(r);
    }

    /** 消耗 1 个鱼饵（优先普通鱼饵，其次任意鱼饵），返回是否豪华饵 */
    private boolean consumeBait(Long userId) {
        UserItem bait = userItemMapper.selectOne(
                Wrappers.<UserItem>lambdaQuery().eq(UserItem::getUserId, userId).eq(UserItem::getItemId, 5L));
        boolean premium = false;
        if (bait == null || bait.getQuantity() <= 0) {
            List<UserItem> baits = userItemMapper.selectList(
                    Wrappers.<UserItem>lambdaQuery().eq(UserItem::getUserId, userId));
            for (UserItem ui : baits) {
                Item it = itemMapper.selectById(ui.getItemId());
                if (it != null && "BAIT".equals(it.getType()) && ui.getQuantity() > 0) {
                    bait = ui;
                    premium = it.getPower() > 0;
                    break;
                }
            }
        }
        if (bait != null) {
            bait.setQuantity(bait.getQuantity() - 1);
            userItemMapper.updateById(bait);
        }
        return premium;
    }

    private Fish pickFish(String tier) {
        List<Fish> pool = switch (tier) {
            case "RARE" -> RARE;
            case "LEGENDARY" -> LEGENDARY;
            default -> COMMON;
        };
        return pool.get(random.nextInt(pool.size()));
    }

    private String tierMessage(String tier, Fish fish) {
        return switch (tier) {
            case "RARE" -> "稀有！" + fish.name + " 上钩，获得 " + fish.value + " 🐚";
            case "LEGENDARY" -> "传说级！" + fish.name + " 被你钓起来了，获得 " + fish.value + " 🐚 🌟";
            default -> "钓到一条 " + fish.name + "，获得 " + fish.value + " 🐚";
        };
    }

    // ===== 鱼池 =====
    @Data
    private static class Fish {
        private final String name;
        private final String icon;
        private final int value;

        Fish(String name, String icon, int value) {
            this.name = name;
            this.icon = icon;
            this.value = value;
        }
    }

    private static final List<Fish> COMMON = List.of(
            new Fish("小丑鱼", "🐠", 15),
            new Fish("热带鱼", "🐟", 25),
            new Fish("河豚", "🐡", 35)
    );

    private static final List<Fish> RARE = List.of(
            new Fish("章鱼", "🐙", 120),
            new Fish("鱿鱼", "🦑", 160),
            new Fish("帝王蟹", "🦀", 220)
    );

    private static final List<Fish> LEGENDARY = List.of(
            new Fish("深海龙鱼", "🐉", 800),
            new Fish("独角鲸", "🐋", 1200),
            new Fish("黄金海马", "👑", 1500)
    );
}
