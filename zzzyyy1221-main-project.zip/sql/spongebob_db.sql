-- ============================================================
-- 比奇堡登录注册 + 钓鱼小游戏 - 数据库初始化脚本
-- 数据库：spongebob_db
-- 适用：MySQL 8.0+
-- 执行方式：mysql -uroot -p123456 < spongebob_db.sql
-- ============================================================

-- 创建数据库（不存在则创建）
CREATE DATABASE IF NOT EXISTS spongebob_db
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE spongebob_db;

-- 用户表
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `username`    VARCHAR(50)  NOT NULL                COMMENT '用户名',
  `email`       VARCHAR(100) NOT NULL                COMMENT '邮箱',
  `password`    VARCHAR(100) NOT NULL                COMMENT '密码（BCrypt 加密存储）',
  `shells`      INT          NOT NULL DEFAULT 50     COMMENT '贝壳余额（游戏货币）',
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci
  COMMENT ='比奇堡用户表';

-- 商店商品目录
DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `name`        VARCHAR(50)  NOT NULL                COMMENT '商品名',
  `type`        VARCHAR(10)  NOT NULL                COMMENT 'ROD 钓竿 / BAIT 鱼饵 / LUCK 幸运物',
  `price`       INT          NOT NULL                COMMENT '售价（贝壳）',
  `power`       INT          NOT NULL DEFAULT 0      COMMENT '钓力 / 幸运加成',
  `icon`        VARCHAR(10)  DEFAULT NULL            COMMENT '展示 emoji',
  `description` VARCHAR(200) DEFAULT NULL            COMMENT '描述',
  `sort`        INT          NOT NULL DEFAULT 0      COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci
  COMMENT ='商店商品目录';

-- 用户背包
DROP TABLE IF EXISTS `user_item`;
CREATE TABLE `user_item` (
  `id`        BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `user_id`   BIGINT NOT NULL                COMMENT '用户 ID',
  `item_id`   BIGINT NOT NULL                COMMENT '商品 ID',
  `quantity`  INT    NOT NULL DEFAULT 0      COMMENT '拥有数量',
  `equipped`  TINYINT NOT NULL DEFAULT 0     COMMENT '是否装备（仅钓竿：1=已装备）',
  PRIMARY KEY (`id`),
  KEY `idx_user_item_user` (`user_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci
  COMMENT ='用户背包';

-- 示例数据（密码均为 BCrypt 加密后的 123456；shells 走字段默认值 50）
INSERT INTO `user` (`username`, `email`, `password`) VALUES
  ('spongebob', 'spongebob@bikini.bottom', '$2a$10$6abzJLWM0DkWMUz/U0jTLeJgDVZvWlyNv9zeGx0vqMEh6RhEaIndC'),
  ('patrick',   'patrick@bikini.bottom',   '$2a$10$dKiaOy1ff6HO3SvKQnAlUOVK8nmrcLhYAxdzVM02MYvDL6wXAjoTy');

-- 商店商品目录（id 固定，便于逻辑引用）
INSERT INTO `item` (`id`, `name`, `type`, `price`, `power`, `icon`, `description`, `sort`) VALUES
  (1, '初级钓竿',   'ROD',  0,    1, '🎣', '比奇堡标配，能钓到常见小鱼',    10),
  (2, '银质钓竿',   'ROD',  200,  2, '🎣', '钓力提升，稀有鱼更易上钩',      20),
  (3, '黄金钓竿',   'ROD',  800,  3, '🎣', '闪闪发光，传说鱼也拦不住',      30),
  (4, '钻石钓竿',   'ROD',  3000, 4, '🎣', '深海霸主专用，极品钓力',        40),
  (5, '普通鱼饵',   'BAIT', 10,   0, '🪱', '每次抛竿消耗 1 个',            50),
  (6, '豪华鱼饵',   'BAIT', 35,   1, '🦐', '提升稀有鱼概率',              60),
  (7, '幸运四叶草', 'LUCK', 500,  2, '🍀', '永久提升稀有 / 传说概率',      70);

-- 示例账号初始道具：1 把初级钓竿（已装备）+ 5 个普通鱼饵
INSERT INTO `user_item` (`user_id`, `item_id`, `quantity`, `equipped`) VALUES
  (1, 1, 1, 1), (1, 5, 5, 0),
  (2, 1, 1, 1), (2, 5, 5, 0);
